#include <pthread.h>
#include <ctime>
#include <iostream>
#include <queue>

using namespace std;
struct A_struct{
    int a;
};

struct B_struct{
    double data[5];
};

int sum_b, sum_b_all=0;
A_struct A_out;
queue<B_struct> B_out;
pthread_mutex_t m;
void* A(){
    srand((unsigned int)(time(0)));
    while(1)A_out.a = rand() % 100 + 1;
    pthread_exit(0);
}
void* B(){
    B_struct out;
    srand((unsigned int)(time(0)));
    while(1){
        for(auto i=0;i<5;i++){
            out.data[i] = (rand() % 100);
            out.data[i] /= 100;
        }
        B_out.push(out);
    }
    pthread_exit(0);
};
void* C(){
    while(1){
        if(B_out.size()>0){
            pthread_mutex_lock(&m);
            auto out = B_out.front();
            B_out.pop();
            pthread_mutex_unlock(&m);
            sum_b = 0;
            for(auto i=0;i<5;i++)sum_b += out.data[i];
            if(A_out.a % 2==0)sum_b *= -1;
            sum_b_all += sum_b;
        }
        else Sleep(10);
        
    }
    pthread_exit(0);
}
void* D(){
    while(1){
            cout << sum_b_all << endl;
            sleep(1);
        }
    }
    pthread_exit(0);
}

int main(int argc, char* argv[]){
    pthread_t a,b,c,d;
    pthread_mutex_init(&m,0);
    B();
    // if(pthread_create(&a, 0, A, 0)!=0){
    //     cout << "Can't create thread A" << endl;
    //     return 1;
    // }
    // if(pthread_create(&b, 0, B, 0)!=0){
    //     cout << "Can't create thread B" << endl;
    //     return 1;
    // }
    // if(pthread_create(&c, 0, C, 0)!=0){
    //     cout << "Can't create thread C" << endl;
    //     return 1;
    // }
    // if(pthread_create(&d, 0, D, 0)!=0){
    //     cout << "Can't create thread D" << endl;
    //     return 1;
    // }
    // pthread_join(a,0);
    // pthread_join(b,0);
    // pthread_join(c,0);
    // pthread_join(d,0);
    pthread_mutex_destroy(&m);
    return 0;
}
